var taskText =  document.querySelector('.container .input-box input')
var actionButton = document.querySelector('.container .input-box button')
var list = document.querySelector('.container .list')
var taskList = []

actionButton.addEventListener('click',()=>{
    if(taskText.value === ''){
        alert('Add your taks first!!')
        return
    }
    taskList.push(taskText.value)
    addToList()
    taskText.value=''

})

function addToList(){
    list.innerHTML = ''
    if(taskList.length===0){
        var pEle = document.createElement('p')
        pEle.classList.add('disabled')
        pEle.innerHTML='no task to be performed'
        list.appendChild(pEle)
    }else{
        for( let i=0;i<taskList.length;i++){
            let taskEle = document.createElement('div')
            taskEle.classList.add('task')


            let taskDetailsEle = document.createElement('div')
            taskDetailsEle.classList.add('task-details')

            let checkIconEle = document.createElement('i')
            checkIconEle.classList.add('fa-regular')
            checkIconEle.classList.add('fa-circle')
            checkIconEle.setAttribute('title','mark completed')
           

            checkIconEle.addEventListener('click',()=>{
              if(checkIconEle.classList.contains('fa-circle')){
                  checkIconEle.classList.remove('fa-circle')
                  checkIconEle.classList.add('fa-circle-check')
                  taskDetailsEle.classList.add('task-checked')
                  checkIconEle.setAttribute.add('title','mark incomplete')
                } else if(checkIconEle.classList.contains('fa-circle-check')){
                  checkIconEle.classList.remove('fa-circle-check')
                  checkIconEle.classList.add('fa-circle')
                  taskEle.classList.remove('task-checked')
                  checkIconEle.setAttribute('title','mark incomplete')
            }
        })

            taskDetailsEle.appendChild(checkIconEle)
         

            let pEle = document.createElement('p')
            pEle.innerHTML = taskList[i]

            taskDetailsEle.appendChild(pEle)

            taskEle.appendChild(taskDetailsEle)

            let deleteIcon = document.createElement('i')
            deleteIcon.classList.add('fa-solid')
            deleteIcon.classList.add('fa-trash')
            deleteIcon.setAttribute('title','Remove Task')
            deleteIcon.addEventListener('click',()=>{
                taskEle.remove()
            })

            


            taskEle.appendChild(deleteIcon)

            list.appendChild(taskEle)

        }
    }
    
}
addToList

